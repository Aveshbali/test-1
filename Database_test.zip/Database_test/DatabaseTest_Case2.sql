*Q-1 List out all questions with it�s answer which is having maximum vote*

select title,poll_answer.pollId,max(answerId) as Maximum_vote from poll,poll_answer,poll_votegroup by answerId , title, poll_answer.pollId;
*Q-2 List out all the categories which is having multiple poll questions under it*

SELECT [poll_question].type, title FROM poll_question
inner join poll
on poll_question.pollId=poll.id
where poll_question.type='multiple';

*Q-3 List out all the polls which are currently active*

SELECT active FROM poll_answer
where active=1;

*Q-4 List out all the users who is not logged in since last week*

SELECT id,firstName,lastLogin
FROM [user] 
WHERE lastLogin  not between getdate()-7 and getdate()
GROUP BY firstName,id,lastLogin

*Q-5 List out all the users whose email provider is not google*

SELECT firstName,email FROM[user] 
WHERE email not LIKE '%gmail.com';

*Q-6 List out all the polls which are published in 2021*

SELECT title,publishedAt FROM poll
WHERE publishedAt LIKE '%2021%';

*Q-7 List out all the users who did not answer any poll yet*

SELECT firstName, pollId, questionId
FROM   [user],poll_answer
INNER JOIN poll 
ON     poll.id = poll_answer.pollId
WHERE  poll_answer.pollID!= poll.id;


*Q-8 Create all the possible unique key and indexes for this database schema*

