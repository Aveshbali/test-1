use Restaurant

select * from [order]

*Q-1 Total income of Restaurant till now. *

select sum(grandTotal) as Total_Income
from [order]

*Q-2  Customer who visited the restaurant more than twice. *

select firstName,  count(userId) as  No_of_time_ordered
from [order]
group by firstName
having count(userId)>=2;

*Q-3  List of all menus with its menu items. *

select menu.title,item.titlefrom iteminner join menu_item on  menu_item.itemId=item.id inner join menuon menu.ID=menu_item.menuId

*Q-5 List out total order placed by each User. *

select firstName,count(*) as Order_placed
from [order]
group by(firstName)

*Q-6  Make a list of each user and the highest-priced menu item he or she ordered. *

select [user].firstName,max(item.price) as Highest_Priced_Item
from [user],item
group by (firstName)

*Q-7 Retrieve the name of a chef who prepares more recipes than any other chef *

select [name],count(chefId)as manyyfrom chef,item_chefwhere chef.id=item_chef.chefIdgroup by [name]order by manyy desc
OFFSET 0 ROWS
FETCH FIRST 1 ROWS ONLY	;

*Q-8 Retrieve the amount of subtotal for all day on 9th November 2021. (It does not include the total, formula: item price * ordered qty).*

select subTotal,createdAt from [order]
where createdAt = '2021-11-09'

*Q-9 List out user along with the average amount spend at the restaurant. *

select firstName,avg(grandTotal) as Average_Amountfrom [order]group by (firstname);*Q-10 List out the menu items which are preferred by the customer at dinner time. *select title as Preffered_timefrom [item]inner join order_itemon order_item.itemId=item.id and datepart(hour,order_item.createdAt)>18;