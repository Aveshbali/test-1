create database Dataset;

use Dataset;

create table Product
(
		product_id int primary key identity not null,
		product_name varchar(128) not null,
		Product_detail varchar(256) not null,
		catagory_id int,
		size varchar(16),
		color varchar(16),
		Quantity_unit int not null,
		price float not null,
		product_available float not null,
		discount int not null,
		product_weight float not null,
		product_sku varchar(50) not null,
		product_image varchar(100) not null, 
		product_cart varchar(250) ,
		product_short varchar(1000)
);

alter table Product
add created_date datetime not null, updated_date datetime not null;


create table Catagory
(
	catagory_id int primary key identity not null,
	catagory_name varchar(64) unique not null,
	catagory_description varchar(100),
	picture varchar(100),
	active varchar(80),
	catagory_date datetime not null,
	updated_date datetime not null
);

create table user_table
(
	user_id int primary key identity not null,
	user_email varchar(32) unique not null,
	user_password varchar(16) not null,
	user_firstname varchar(16) not null,
	user_lastname varchar(16) not null,
	user_phone varchar(16) not null,
	user_dob datetime,
	user_gender varchar(8) not null
);

create table user_address
(
	id int primary key identity not null,
	user_id int,
	house_no int not null,
	street varchar(64) not null,
	area varchar(64) not null,
	city varchar(32) not null,
	pincode varchar(10) not null,
	user_state varchar(32) not null,
	country varchar(16) not null
);

create table order_table
(
	order_id int primary key identity not null,
	user_id int,
	order_status varchar(32) not null,
	amount varchar(32) not null,
	order_date datetime not null,
	phone varchar(16) not null,
	payment_status varchar(32) not null
);

alter table order_table
add address_id int;

create table order_address
(
	address_id int primary key identity not null,
	user_id int,
	id int
	address_type bit(1) not null
);