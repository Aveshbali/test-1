create database Customer;

use Customer;

create table customer(
	id int primary key identity not null,
	name varchar(24) not null 
);

create table orders(
id int primary key identity not null,
customerId int foreign key references customer(id)
);

insert into customer(name) values ('Joe');
insert into customer(name) values ('Henry');
insert into customer(name) values ('Sam');
insert into customer(name) values ('Max');

insert into orders (customerId) values ('3');
insert into orders (customerId) values ('1');

select name as customers from customer where id not in(select customerId from orders);

