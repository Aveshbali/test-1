create database Indexemail;

use Indexemail;

create table indextable(
	id int primary key identity not null,
	email varchar(32) not null
);

create index i1 on indextable(email);