create database Person_data;

use Person_data;

create table person_data(
	person_id int primary key identity not null,
	firstname varchar(16) not null,
	lastname varchar(16) not null
);

create table person_address(
	address_id int primary key identity not null,
	person_id int,
	city varchar(32) not null,
	state varchar(32) not null
);

insert into person_data(firstname,lastname) values ('Allen','Wang');
insert into person_data(firstname,lastname) values ('Bob','Alice');

insert into person_address(person_id,city,state) values ('2','New York city','New York');
insert into person_address(person_id,city,state) values ('3','Leetcode','California');

select * from person_data
left join person_address on 
person_data.person_id=person_address.person_id;