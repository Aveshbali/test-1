create database Person;

use Person;

create table person(
	id int primary key identity not null,
	email varchar(20) not null
);

insert into person(email) values ('john@example.com');
insert into person(email) values ('bob@example.com');
insert into person(email) values ('john@example.com');

select * from person;
delete from person where id not in (select * from (select min(id)from person group by email)as id);
