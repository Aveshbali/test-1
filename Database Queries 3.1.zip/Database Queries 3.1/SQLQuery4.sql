create database Salary;

use Salary;

create table salary(
	ID int identity not null primary key,
	name varchar(32) not null,
	sex varchar(1) not null,
	salary int not null
);

insert into salary(name,sex,salary) values('A','m','2500');
insert into salary(name,sex,salary) values('B','f','1500');
insert into salary(name,sex,salary) values('C','m','5500');
insert into salary(name,sex,salary) values('D','f','500');
insert into salary(name,sex,salary) values('A','d','2500');

select *from salary;

delete from salary where id=5;
select * from salary;

alter table salary 
with check add constraint sex
check (([sex] ='m' OR [sex]='f'))

update salary set "sex" = (case "sex" when 'm' then 'f' else 'm' end);
select *from salary;