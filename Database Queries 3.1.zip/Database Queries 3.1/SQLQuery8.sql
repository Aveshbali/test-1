create database student_data;

use student_data;

create schema student;

create table student.sem_master(
	sem_id int primary key identity not null,
	sem_num int not null
);

create table student.subject_master(
	sub_id int primary key identity not null,
	subject_name varchar(16) not null
);

create table student.data(
	roll_no int primary key identity not null,
	name varchar(24) not null,
	dob datetime not null,
	sem_id int,
	sub_id int,
	grade varchar(8) not null
);