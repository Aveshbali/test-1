create database Cinema;

use Cinema;

create table cinema(
	id int primary key identity not null,
	movie varchar(32) not null,
	description_1 varchar(16) not null,
	ratings float not null
);

insert into cinema(movie,description_1,ratings) values('war','great3d','8.9');
insert into cinema(movie,description_1,ratings) values('Sceince','Fiction','8.5');
insert into cinema(movie,description_1,ratings) values('irish','boring','6.2');
insert into cinema(movie,description_1,ratings) values('Ice Song','Fantacy','8.3');
insert into cinema(movie,description_1,ratings) values('House Card','Interesting','9.1');

select * from cinema
where (id%2) = 1 and description_1 != 'boring'
order by ratings DESC;

