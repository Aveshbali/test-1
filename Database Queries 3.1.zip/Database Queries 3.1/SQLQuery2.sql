create database Employee

use Employee;
create table employee(
emp_id int primary key identity not null,
emp_nm varchar(48) not null,
salary int not null,
dob datetime not null,
join_date datetime not null,
mobile varchar(16) not null,
gender varchar(8) not null
);

use Employee;

create table department(
dep_id int primary key identity not null,
dep_name varchar(32) not null,
designation varchar(32) not null
);

alter table department
add emp_id int;

use Employee;

create table leave(
emp_id int,
dep_id int,
leave_id int primary key identity not null,
leave_start datetime not null,
leave_end datetime not null,
leave_type varchar(32) not null
);