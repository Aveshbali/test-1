create database Student;

use Student;

create table student_table(
	student varchar(2) not null,
	class varchar(16) not null
);

insert into student_table(student,class) values ('A','Math');
insert into student_table(student,class) values ('B','English');
insert into student_table(student,class) values ('C','Math');
insert into student_table(student,class) values ('D','Biology');
insert into student_table(student,class) values ('E','Math');
insert into student_table(student,class) values ('F','Computer');
insert into student_table(student,class) values ('G','Math');
insert into student_table(student,class) values ('H','Math');
insert into student_table(student,class) values ('I','Math');

select * from student_table;

select class from student_table
group by class
having count(distinct student) >= 5;