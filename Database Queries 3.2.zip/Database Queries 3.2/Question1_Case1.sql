create database Activity;

use Activity;

create table activity(
	player_id int not null,
	device_id int not null,
	event_date datetime not null,
	games_played int not null,
	constraint a_activity primary key(player_id,event_date)
);

insert into activity values(1,2,'2016-03-01', 5);insert into activity values(1,2,'2016-05-02', 6);insert into activity values(2,3,'2017-06-25', 1);insert into activity values(3,1,'2016-03-02', 0);insert into activity values(3,4,'2018-07-03', 5);

select player_id, min(event_date) as first_login
from activity
group by player_id;

select a.player_id, a.device_id
from activity a JOIN
(select player_id, min(event_date) 'first_login'
from activity group by player_id) t
ON a.player_id=t.player_id and a.event_date = t.first_login;

select a1.player_id, a1.event_date ,sum(a2.games_played) as games_played_so_far
from activity a1, activity a2
where a1.player_id = a2.player_id
and a1.event_date >=a2.event_date
group by a1.player_id, a1.event_date
order by a1.player_id, a1.event_date;